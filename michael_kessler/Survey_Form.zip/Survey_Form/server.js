var express = require('express')
var app = express()
var bodyParser = require('body-parser')
var session = require('express-session')

//set
app.set('views', __dirname + '/views')
app.set('view engine', 'ejs')

//use
app.use(bodyParser.urlencoded( { extended: true } ))
app.use(session( { secret: 'secretkey' } ))

//routes
app.get('/', (req, res) =>{
	return res.render('index')
})

app.post('/submit', (req, res) => {
	user = req.body
	return res.redirect('/results')
})

app.get('/results', (req, res)=>{

	return res.render('results')
})

app.post('/goback', (req, res) => {
	return res.redirect('/')
})

//runserver always at bottom
app.listen(8000, () => {
	console.log('listening to port 8000')
})