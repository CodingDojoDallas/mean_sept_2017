import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	array = []

	fillArray(){
	for(let y=0; y<10; y++){
		const randNum = (Math.floor(Math.random() * 9)) +1;
		if(randNum === 1){
			this.array.push('0000FF')
		} else if(randNum === 2){
			this.array.push('008000')
		}else if(randNum === 3){
			this.array.push('4169E1')
		}else if(randNum === 4){
			this.array.push('008000')
		}else if(randNum === 5){
			this.array.push('FF0000')
		}else if(randNum === 6){
			this.array.push('8B008B')
		}else if(randNum === 7){
			this.array.push('00FFFF')
		}else if(randNum === 8){
			this.array.push('696969')
		}else if(randNum === 9){
			this.array.push('FF4500')
		}else if(randNum === 10){
			this.array.push('FFD700')
		}
	}
}
	ngOnInit() {
		this.fillArray()
	}
}
 

// colors = ['0000FF', "008000", '4169E1', '800000', 'FF0000', '8B008B', '00FFFF', '696969', 'FF4500', 'FFD700']