import { TestBed, inject } from '@angular/core/testing';

import { GitScoreService } from './git-score.service';

describe('GitScoreService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GitScoreService]
    });
  });

  it('should be created', inject([GitScoreService], (service: GitScoreService) => {
    expect(service).toBeTruthy();
  }));
});
