import { Injectable } from '@angular/core';
import { Http } from '@angular/http'

@Injectable()
export class GitScoreService {

	// score: object;

  constructor(private _http: Http) { }

  retrieveScore(callback, bob){
  	this._http.get(`https://api.github.com/users/${bob}`).subscribe((response) => {
  		// this.score = response.json()
  		// callback(this.score)
      callback(response.json());
  	},
  	(err) => {
  		console.log(err)
  	}
 	)
  }
}
