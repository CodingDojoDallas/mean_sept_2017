import { Component, OnInit } from '@angular/core';
import { GitScoreService } from './../git-score.service'

@Component({
  selector: 'app-score-dashboard',
  templateUrl: './score-dashboard.component.html',
  styleUrls: ['./score-dashboard.component.css']
})
export class ScoreDashboardComponent implements OnInit {
	total:number;
	score: any = {}

	newUser = { name: 'Michael' };

  constructor(private _gitScoreService: GitScoreService) { }

  ngOnInit() {
  	// console.log(this.score.followers)
  }

  retrieveScore() {
  	console.log(this.newUser);
  	this._gitScoreService.retrieveScore(
  		(data) => { 
  			this.score = data;
  			this.total = this.score.public_repos + this.score.followers;
  			console.log(this.score);
  		},
  		this.newUser.name
  	);  	
  }
  
  

}
