import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  emails = [
  {
  	address: 'BILL@gates.com',
  	importance: true,
  	subject: 'New Windows',
  	content: 'Windows will launch'
  },
  {
  	address: 'mkessler83@gmail.com',
  	importance: false,
  	subject: 'My contact info',
  	content: 'This is my email address'
  }
  ]
}

