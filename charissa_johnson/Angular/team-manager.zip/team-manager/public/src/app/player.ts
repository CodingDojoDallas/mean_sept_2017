export class Player {
	_id:string;
	name:string;
	position:string;
	createdAt:any;
	updatedAt:any;
	games: Object = { 
		game1: 'undecided',
		game2: 'undecided',
		game3: 'undecided'
	}
}
