import { Component, OnInit } from '@angular/core';
import { PlayerService } from '../../player.service';
import { Router } from '@angular/router';
import { Player } from '../../player';

@Component({
  selector: 'app-player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.css']
})
export class PlayerListComponent implements OnInit {

  constructor(private _playerSerivce: PlayerService, private _router: Router) { }

  allPlayers: Array<Player>

  ngOnInit() {
  	this.getPlayers();
  }

  getPlayers() {
    this._playerSerivce.retrieveAll()
    .then((players) => {
      this.allPlayers = players;})
    .catch((err) => {console.log(err)});
  }

  deletePlayer(player) {
    let del = confirm(`Are you sure you want to remove ${player.pname}?`);
    if (del) {
      this._playerSerivce.destroy(player)
      .then(() => {this.getPlayers();})
      .catch((err) => {console.log("the error is:", err)});
    }
  }

}
