import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-players',
  templateUrl: './manage-players.component.html',
  styleUrls: ['./manage-players.component.css']
})
export class ManagePlayersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
