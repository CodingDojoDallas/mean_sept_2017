import { Component, OnInit } from '@angular/core';
import { PlayerService } from '../../player.service';
import { Router } from '@angular/router';
import { Player } from '../../player';

@Component({
  selector: 'app-player-new',
  templateUrl: './player-new.component.html',
  styleUrls: ['./player-new.component.css']
})
export class PlayerNewComponent implements OnInit {

  player = new Player();

  constructor(private _playerService: PlayerService, private _router: Router) { }

  ngOnInit() {
  }

  addPlayer() {
    this._playerService.create(this.player)
    .then(() => {this._router.navigate(['/manage/player/list'])})
    .catch((err) => {console.log(err)});
  }
}
