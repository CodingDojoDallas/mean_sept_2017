import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageplayers',
  templateUrl: './manageplayers.component.html',
  styleUrls: ['./manageplayers.component.css']
})
export class ManageplayersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}