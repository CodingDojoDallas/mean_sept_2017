export const TASKS: Task[] = [
    {
      _id: 11,
      title: 'Code like crazy',
      completed: true,
    },
    {
      _id: 23,
      title: 'Become a Ninja',
      completed: false
    },
    {
      _id: 42,
      title: 'Remember to Sleep',
      completed: false,
    },
    {
      _id: 32,
      title: 'Be a Leader',
      completed: true
    }
  ];