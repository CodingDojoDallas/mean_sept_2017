import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-washington',
  templateUrl: './washington.component.html',
  styleUrls: ['./washington.component.css']
})
export class WashingtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
