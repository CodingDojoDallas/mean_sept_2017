import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-san-jose',
  templateUrl: './san-jose.component.html',
  styleUrls: ['./san-jose.component.css']
})
export class SanJoseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
