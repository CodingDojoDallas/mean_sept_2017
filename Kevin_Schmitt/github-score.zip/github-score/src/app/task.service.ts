import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class TaskService {
  Newresponse:object = {
    
  };

  constructor(private _http: Http) { }

  
  getSource(source: string){
    this._http.get(`https://api.github.com/users/${source}`).subscribe(
      (response) => {
        console.log('res:', response._body);
        console.log(response,response.url)
      },
      (err) => console.log(err)
    );
  }
}
